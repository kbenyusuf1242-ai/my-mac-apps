# Third-party Code

## dnsinfo.h

Header file that defines the private `dns_configuration_copy()` and related APIs on iOS and macOS. Taken from [apple-oss-distributions/configd/](https://github.com/apple-oss-distributions/configd/) as of [version 1163.140.3](https://github.com/apple-oss-distributions/configd/blob/configd-1163.140.3/dnsinfo/dnsinfo.h).

The original source code is distributed under the Apple Public Source License 2.0 (APSL) and any modifications would need to be published (there currently aren't any).
